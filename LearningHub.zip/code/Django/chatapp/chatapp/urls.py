from chat.urls import include, path
from chat.views import ChatMessageList  # Make sure this import is correct

urlpatterns = [
    path('chat/', include('chat.urls')),
    path('api/messages/', ChatMessageList.as_view(), name="get_old_messages"),
]



# from django.contrib import admin
# from django.urls import path, include

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('', include('chat.urls')),
# ]
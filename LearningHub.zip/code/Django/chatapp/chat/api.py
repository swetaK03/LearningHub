from rest_framework import generics
from .models import ChatMessage
from .serializers import UserSerializer
from django.contrib.auth.models import User
from django.db.models import Q

class ChatMessageList(generics.ListAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        sender_id = self.request.query_params.get('sender')
        receiver_id = self.request.query_params.get('receiver')

        if sender_id and receiver_id:
            return ChatMessage.objects.filter(
                Q(sender_id=sender_id, receiver_id=receiver_id) | Q(sender_id=receiver_id, receiver_id=sender_id)
            ).order_by('timestamp')
        return ChatMessage.objects.none()
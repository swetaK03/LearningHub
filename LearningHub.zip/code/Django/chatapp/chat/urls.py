from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('login/', views.login_view, name='login'),
]
urlpatterns += [
    path('<int:user_id>/', views.chat_with_user, name='chat_with_user'),
]

from django.urls import path, include
from rest_framework import routers
from . import views

router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('home/', views.chat_home, name='chat_home'),
    path('api/', include(router.urls)),
]
from django.urls import path
from . import views

urlpatterns = [
    path('chat/<int:user_id>/', views.chat_with_user, name='chat_with_user'),
]

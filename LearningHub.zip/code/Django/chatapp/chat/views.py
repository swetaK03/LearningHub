# from django.shortcuts import render

# # Create your views here.
# from django.contrib.auth.models import User
# from django.contrib.auth import login, authenticate
# from django.shortcuts import render, redirect
# from django.http import HttpResponse


# from django.contrib.auth.decorators import login_required

# @login_required
# def chat_home(request):
#     users = User.objects.exclude(id=request.user.id)
#     return render(request, 'chat_home.html', {'users': users})

# from django.shortcuts import get_object_or_404

# @login_required
# def chat_with_user(request, user_id):
#     receiver = get_object_or_404(User, id=user_id)
#     messages = Message.objects.filter(
#         sender__in=[request.user, receiver],
#         receiver__in=[request.user, receiver]
#     ).order_by('timestamp')
#     return render(request, 'chat.html', {'receiver': receiver, 'messages': messages})


# def signup(request):
#     if request.method == "POST":
#         username = request.POST['username']
#         password = request.POST['password']
#         user = User.objects.create_user(username=username, password=password)
#         return redirect('login')
#     return render(request, 'signup.html')

# def login_view(request):
#     if request.method == "POST":
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             login(request, user)
#             return redirect('chat_home')
#         else:
#             return HttpResponse("Invalid login")
#     return render(request, 'login.html')

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from rest_framework import viewsets
from django.contrib.auth.models import User
from .serializers import UserSerializer

from rest_framework.views import APIView
from rest_framework.response import Response

class ChatMessageList(APIView):
    def get(self, request):
        # Example data, replace with your actual logic
        messages = [{"id": 1, "content": "Hello"}, {"id": 2, "content": "World"}]
        return Response({"messages": messages})

from django.shortcuts import render

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer


def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('chat_home')
    else:
        form = UserCreationForm()
    return render(request, 'chat/signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('chat_home')
    else:
        form = AuthenticationForm()
    return render(request, 'chat/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def chat_home(request):
    return render(request, 'chat/chat_home.html')

from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render
from .models import User, Message


@login_required
def chat_with_user(request, user_id):
    receiver = get_object_or_404(User, id=user_id)
    if request.method == "POST":
        content = request.POST.get('message')
        if content:  # Ensure the message is not empty
            Message.objects.create(sender=request.user, receiver=receiver, content=content)
    
    messages = Message.objects.filter(
        sender__in=[request.user, receiver],
        receiver__in=[request.user, receiver]
    ).order_by('timestamp')
    
    return render(request, 'chat.html', {'receiver': receiver, 'messages': messages})

from django.shortcuts import render

def signup(request):
    return render(request, 'chat/signup.html')

